s = 'Hello world!'
print(s[1:4])
print(s[4:])
print(s[-2:])
print(s[1:50])
