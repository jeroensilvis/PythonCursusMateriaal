import re

f = open('alice.txt')
text = f.read()
pattern = r'[A-Z]+\s'
regexp = re.compile(pattern)
result = re.findall(regexp,text)

result = [e[:-1] for e in result]
print(result)