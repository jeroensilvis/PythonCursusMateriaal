import pickle

f = open('dump.txt', 'rb')
data = pickle.load(f)
f.close()
print(data)
