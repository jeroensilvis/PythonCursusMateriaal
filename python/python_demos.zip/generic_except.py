def open_file():
    try:
        f = open('aFile')
    except:
        print("Can't open file")


open_file()
