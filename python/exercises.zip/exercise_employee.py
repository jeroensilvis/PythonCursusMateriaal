import datetime

class Employee:

    """"
    Employee class

    >>> p = Employee('Hans','Anders',1000)

    >>> print(p)
    Hans Anders 1000 2017-05-26
    """

    def __init__(self,firstName="No Name",lastName="No Name",salary=0):
        self._firstName = firstName
        self._lastName = lastName
        self._salary = salary
        self._joinDate = datetime.date.today()

    @property
    def firstName(self):
        """
        get firsName of employee

        >>> p.firstName
        'Hans'
        """
        return self._firstName

    @firstName.setter
    def firstName(self,value):
        self._firstName = value

    @property
    def lastName(self):
        return self._lastName

    @lastName.setter
    def lastName(self, value):
        self._lastName = value

    @property
    def salary(self):
        return self._salary

    @salary.setter
    def salary(self, value):
        self._salary = value

    @property
    def joinDate(self):
        return self._joinDate

    @joinDate.setter
    def joinDate(self, value):
            self._joinDate = value

    def __str__(self):
        return self._firstName+' '+self._lastName+' '+str(self._salary) +' '+ str(self._joinDate)

    def payRaise(self, amount):
        self._salary += amount


p = Employee('Hans','Evers',10000)
print(p)
p.payRaise(2000)
print(p)


        
        
    
        
    
