l = [1, 2, 3, 4, 5, 6, ]
m = [n ** 2 for n in l]
print(m)
k = [n for n in l if n % 2 == 0]
print(k)
