import math
"""
Iterable class which generates prime numbers
"""


class Prime:
    """
    Iterable which generates prime number between min and max.
    max included
    """

    def __init__(self, min=2, max=0):
        if min < 2:
            self.min = 2
        else:
            self.min = min
        self.max = max
        self.number = self.min

    def __iter__(self):
        return self

    def __next__(self):
        while True:
            is_prime = True
            for e in range(2, int(math.sqrt(self.number) + 1)):
                if self.number % e == 0:
                    is_prime = False
                    break
            if is_prime:
                prime = self.number;
                self.number += 1
                return prime
            else:
                self.number += 1
                if self.number > self.max:
                    raise StopIteration


if __name__ == '__main__':
    p = Prime(min=20, max=100)
    for i in p:
        print(i)
