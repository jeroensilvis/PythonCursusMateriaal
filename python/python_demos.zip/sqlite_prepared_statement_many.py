import sqlite3

employees = [('Peter', 'Haantjes', 5000),
             ('Sanne', 'Jongejans', 6000),
             ('Ruud', 'van der mark', 2100)]

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.executemany("INSERT INTO Employee(FirstName,LastName,Salary) VALUES(?,?,?)", employees)
