list1 = ['a', 'b', 'c', 'd', 'e']
list2 = [1, 2, 3, 4]

dict1 = dict(zip(list1, list2))
print(dict1)
