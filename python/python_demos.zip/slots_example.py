class Account:

    __slots__ = ('name','balance')

    def __init__(self, name, balance):
        self.name = name
        self.balance = balance

    def get_balance(self):
        return self.balance


a = Account("Peter", 2000)
print(a.__slots__)
print(a.__dict__)
