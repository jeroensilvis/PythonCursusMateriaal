import math

square_root = lambda x: math.sqrt(x)
print(square_root(16))

pairs = [(2, 'two'), (4, 'four'), (1, 'one'), (3, 'three')]
pairs.sort()
print(pairs)
pairs.sort(key=lambda pair: pair[1])
print(pairs)
