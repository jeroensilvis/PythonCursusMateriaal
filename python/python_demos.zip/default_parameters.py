def get_squares(max_value=20):
    return [n ** 2 for n in range(max_value)]


def get_squares_between(min_value, max_value=20):
    return [n ** 2 for n in range(min_value, max_value)]


print(get_squares())
print(get_squares(15))
print(get_squares_between(10))
print(get_squares_between(15, 25))
