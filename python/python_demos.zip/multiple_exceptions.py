def generate_exceptions(z):
    try:
        x = 10
        c = x / z  # Can generate a ZeroDivisionError

        d = (1, 2, 3)
        d[0] = 4  # Is a TypeError
    except ZeroDivisionError as e:
        print(e)
    except TypeError as e:
        print(e)


generate_exceptions(0)
generate_exceptions(10)
