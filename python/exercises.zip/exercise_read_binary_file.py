with open('textfile.txt','w') as f:
    f.write('This is a text file.')
    f.write('This file is read as a binary file.')
with open('textfile.txt','rb') as f:
    for b in f.read():
        print(b)
