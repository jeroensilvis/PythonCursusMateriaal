from collections import namedtuple

Task = namedtuple('Task', ['content', 'owner', 'status'])


def change_content(t, content):
    return Task(content, t.owner, t.status)


def change_owner(t, owner):
    return Task(t.content, owner, t.status)


def change_status(t, status):
    return Task(t.content, t.owner, status)



