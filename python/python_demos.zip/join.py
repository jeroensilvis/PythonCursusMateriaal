s = '-'.join(['Hans', 'Robert', 'Leo'])
print(s)
