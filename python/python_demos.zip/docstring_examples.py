"""This module is created to show docstrings"""


def add(x, y):
    """Returns the sum of x and y"""
    return x + y


class SavingsAccount:
    """The class SavingsAccount mirrors the savings account
        of the bank.
        * there are two fields
            -balance
            -overdue_max
        * there are two methods
            extract_money
            add_money """

    pass


class Point:
    """ Point on a plane.
        Distances are calculated using hypotenuse.
        >>> p_1 = Point(22, 7)
        >>> p_1.x
        22
        >>> p_1.y
        7
        >>> p_1
        Point(22, 7)
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod(verbose=1)
