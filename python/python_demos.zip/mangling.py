class Person:
    def __init__(self, name, age):
        self.__name = name
        self._age = age


p = Person('Hans', 32)
print(dir(p))
