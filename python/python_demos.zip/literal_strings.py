s1 = 'A string which continues \
     on the next line'
s2 = 'A string with a\n linefeed'
s3 = '''A string
        spanning
        more lines'''
s4 = 'A string with a back slash \\'
print(s1)
print(s2)
print(s3)
print(s4)