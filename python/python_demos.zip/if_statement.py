grade = 'E'
if grade == 'A':
    print('Excellent')
elif grade == 'B':
    print('Good')
elif grade == 'C':
    print('Sufficient')
else:
    print('Not good')

