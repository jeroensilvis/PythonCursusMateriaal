s = [1, 'a', 3.4, 12]
print(s[0])
print(s[-1])
print(s[-2])
# print(s[4])

t = (3, 'hello', 50)
print(t[0])
print(t[1])
print(t[-1])

s = 'World'
print(s[0])
print(s[-1])
print(s[len(s) - 1])
