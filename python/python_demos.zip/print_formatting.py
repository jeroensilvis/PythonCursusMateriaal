name = 'Leon'
score = 9.9
print('The score of %s is %.1f' % (name, score))

print('The score is {} is {}'.format(name, score))

print('The score of', name, 'is', score)

print('The score of', name, 'is', score, sep='!')
