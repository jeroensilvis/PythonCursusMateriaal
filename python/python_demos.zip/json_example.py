import json

jsonData = '{"name": "Frank", "age": 39}'
jsonToPython = json.loads(jsonData)
print(jsonToPython)

import json

pythonDictionary = {'name': 'Bob', 'age': 44, 'isEmployed': True}
dictionaryToJson = json.dumps(pythonDictionary)
print(dictionaryToJson)
