squares = map(lambda x: x ** 2, range(10))
special_squares = filter(lambda x: x > 5 and x < 50, squares)
print(list(special_squares))
