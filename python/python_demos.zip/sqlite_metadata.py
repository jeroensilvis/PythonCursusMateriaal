import sqlite3
import sys

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("PRAGMA table_info(Employee)")
    result = cursor.fetchall()
    print(result)
