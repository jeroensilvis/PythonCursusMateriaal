import sqlite3

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Employee(FirstName,LastName,Salary) VALUES(?,?,?)", ('Anita','Bruin',4000))
