while True:
    pass


class MyClass:
    pass


def addition(first, second):
    print(first + second)


addition(second=40, first=30)
addition(30, second=40)
