my_variable = 100


def addition(plus):
    print('The result after addition is :', my_variable + plus)
