#! /usr/bin/python
import sys

print('Prime numbers progam')
print('The number of arguments is :',len(sys.argv))
print('Argument list:',str(sys.argv))
_,*numbers = sys.argv
print(numbers)
for n in numbers:
    nr = int(n)
    prime = True
    for i in range(2,nr-1):
        if nr%i == 0:
            prime = False
            break
        if prime:
            print("Prime number :",n)
