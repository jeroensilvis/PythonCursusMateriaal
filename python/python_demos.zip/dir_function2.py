class MyClass:
    def __init__(self, age, name, id_nr):
        self.age = age
        self.name = name
        self.id_nr = id_nr

    def extra(self, license_plate):
        self.license_plate = license_plate


print(dir(MyClass))
m = MyClass(23, 'John', 100)
print(dir(m))
m.extra(2345)
print(dir(m))
