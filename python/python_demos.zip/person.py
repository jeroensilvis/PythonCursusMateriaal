class Person:
    
    def __init__(self, name='', age=-1):
        self.name = name
        self.age = age

    def __str__(self):
        return f'{self.name} {self.age}'


class Employee(Person):
    emp_nr = 1

    def __init__(self, name='', age=-1, salary=0):
        super().__init__(name, age)
        self.salary = salary
        self.number = Employee.emp_nr
        Employee.emp_nr += 1

    @classmethod
    def get_nr(cls):
        return cls.emp_nr

    @staticmethod
    def some_method():
        print("this is a static method")

    def get_mynumber(self):
        return self.number

    def __str__(self):
        return super().__str__() + f' {self.salary} {self.number}'

    def raise_salary(self, amount):
        self.salary += amount

    def __lt__(self,e):
        if isinstance(e,Employee):
            return self.name < e.name
        else:
            raise Exception('Wrong type')


if __name__ == '__main__':
    employees = [Employee('Dave', 37, 4000),Employee("Amy", 31, 5000),Employee("Andy",45,4500)]
    # employees.sort()

    employees.sort()
    for e in employees:
        print(e)
