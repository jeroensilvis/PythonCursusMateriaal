s = 'hello'
print(s.find('lo'))
print(s.find('kl'))
print('3'.isdigit())
print('     hello'.lstrip())
print(s.upper().find('lo'))
print(s)
print(s.upper().find('LO'))
s = 'Hello world!'
print(s.split(' '))

