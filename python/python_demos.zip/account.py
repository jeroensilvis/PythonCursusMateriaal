class Account():

    def __init__(self,name='', balance=0):
        self._name = name
        self._balance = balance

    def get_name(self):
        return self._name

    def set_name(self, name):
        self._name = name

    def get_balance(self):
        return self._balance

    def set_balance(self, balance):
        self._balance = balance

    def __str__(self):
        return self.get_name() + ' ' + str(self.get_balance())


class SavingsAccount(Account):

    def __init__(self,name='',balance=0,interest=0):
        super().__init__(name,balance)
        self._interest = interest

    def get_interest(self):
        return self._interest

    def set_interest(self,interest):
        self._interest = interest

    def __str__(self):
        return super().__str__() + ' ' + str(self.get_interest())


if __name__ == '__main__':
    # andre = Account('Andre', 1000)
    # han = Account("Han", 100)
    # albert = Account('Albert', 25)
    # n = Account()
    # n.set_balance(1000)
    # n.set_name('Ruben')
    #
    # print(han)
    # print(andre)
    # print(albert)
    # print(n)

    s = SavingsAccount('Piet',1000,1)
    print(s.get_name())
    print(s.get_balance())
    print(s.get_interest())
    print(s)

