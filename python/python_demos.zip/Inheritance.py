class Person:

    def __init__(self, name):
        self.name = name

    def __str__(self):
        return self.name


class Employee(Person):

    def __init__(self, name, salary):
        super().__init__(name)
        self.salary = salary

    def __str__(self):
        return super().__str__() + ',' + str(self.salary)


class Manager(Employee):
    pass


e = Employee('Peter', 1000)
print(e)
