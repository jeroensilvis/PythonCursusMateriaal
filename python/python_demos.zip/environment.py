import os

print(os.environ['PATH'])
print(os.environ['USER'])
print(os.environ['HOME'])
print(os.getcwd())
print(os.uname())
