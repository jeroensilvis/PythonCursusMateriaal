import pickle

data = ['Hello', 1, {'a': 1, 'b': 2}, 'd']
f = open('dump.txt', 'wb')
pickle.dump(data, f)
f.close()
