print('The program will decide if the word you put in is a palindrome')
while True:
    word = input('Please, put in a word\n')
    word = word.lower()
    if word == word[::-1]:
        print('The word is a palindrome')
    else:
        print('The word is not a palindrome')
