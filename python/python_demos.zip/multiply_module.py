def multiply(x, y):
    """
    this function multiplies x with y
    """
    return x * y
