import sqlite3

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("INSERT INTO Employee VALUES(5,'Maria','CEO',30000)")

    cursor.execute("SELECT * FROM Employee")
    while True:
        row = cursor.fetchone()
        if row is None:
            break
        print(row[1], row[2])
