my_variable = 10

if __name__ == '__main__':
    print('This is the main file')
    print(my_variable)
