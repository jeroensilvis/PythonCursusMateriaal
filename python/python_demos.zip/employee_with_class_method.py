class Employee:
    _max_salary = 5000;  # class variable

    def __init__(self, name):
        self.name = name  # instance variable

    @classmethod
    def get_max_salary(cls):
        return cls._max_salary


print(Employee.get_max_salary())
