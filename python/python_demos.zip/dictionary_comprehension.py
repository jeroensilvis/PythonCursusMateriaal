d = {x: x ** 2 for x in range(5)}
print(d)

d = {x: x ** 2 for x in range(5) if x % 2 == 0}
print(d)
