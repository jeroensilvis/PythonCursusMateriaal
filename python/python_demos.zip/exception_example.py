def division(x, y):
    try:
        return x / y
    except ZeroDivisionError:
        print('division by zero')


print(division(5, 2))
print(division(5, 0))


def division(x, y):
    try:
        return x / y
    except ZeroDivisionError as e:
        print(e)


print(division(5, 2))
print(division(5, 0))
