class QuizItem:

    def __init__(self, id, question, answer, cat, diff):
        self.id = id
        self.question = question
        self.answer = answer
        self.cat = cat
        self.diff = diff

    def __str__(self):
        return f'{self.id} {self.question} {self.answer} {self.cat} {self.diff}'

    def make_tuple(self):
        return self.id, self.question, self.answer, self.cat, self.diff
