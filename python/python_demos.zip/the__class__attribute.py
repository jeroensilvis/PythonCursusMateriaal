class Account:
    def __init__(self, name, balance):
        self.name = name
        self.balance = balance

    def get_balance(self):
        return self.balance


a = Account("Peter", 2000)
print(a.__class__.__dict__)
print(Account.__dict__)
