import math
"""
Module with generator which generates prime numbers
"""


def prime_generator(min=2, max=2):
    """
    The generator function
    :param min: lower bound for prime numbers
    :param max: upper bound for prime number, bound included
    :yield: a prime number
    """
    if min < 2:
        min = 2
    number = min
    while number <= max:
        is_prime = True
        for e in range(2, int(math.sqrt(number) + 1)):
            if number % e == 0:
                is_prime = False
                break
        if is_prime:
            yield number
        number += 1


if __name__ == '__main__':
    x = prime_generator(20, 100)
    try:
        while True:
            print(next(x))
    except StopIteration:
        print('Done')
