l = 'H,e,l,l,o'.split(',')
print(l)
