import random
"""
Create a list of 20 numbers.
Each number is a random integer between 0 and 9, 9 included.
1. Create a new list with the unique numbers in the list.
2. Create a new list with the unique numbers but keep the original ordering.
"""

my_list = [random.randint(0, 9) for n in range(20)]
print(my_list)

result1 = list(set(my_list))
print(result1)

my_dict = dict.fromkeys(my_list)
print(my_dict)
result2 = list(my_dict.keys())
print(result2)

result3 = []
[result3.append(item) for item in my_list if item not in result3]
print(result3)