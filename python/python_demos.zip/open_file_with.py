with open('output.txt', 'w') as f:
    f.write('Hi there!')
