a = {42, 12.9, 'world'}
print(a)
a = {304}
print(a)
a = set()
print(a)
a = set('Hello')
print(a)
a.add('!')
print(a)
a = frozenset('Hello')
print(a)
# a.add('!')

s = {1, 4, 6, 2}
print(s)
t = {5, 4}
print(s.issubset(t))
print(s.issuperset(t))
print(s.union(t))
s.discard(5)
print(s)

print(s < t)  # is proper subset
print(s <= t)  # is subset
print(s | t)  # union
print(s & t)  # intersection
print(s - t)  # difference
print(s ^ t)  # symmetric difference
