import pytest
from exercise_pytest import *


@pytest.fixture()
def create_task():
    return Task('Do some work', 'Hans', True)


def test_change_content(create_task):
    t = create_task
    assert change_content(t, 'No work') == Task('No work', t.owner, t.status)


def test_change_owner(create_task):
    t = create_task
    assert change_owner(t, 'Peter') == Task(t.content, 'Peter', t.status)


def test_change_status(create_task):
    t = create_task
    assert change_status(t, False) == Task(t.content, t.owner, False)

