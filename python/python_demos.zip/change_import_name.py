import math as m

print('The sinus of 0 is :', m.sin(0))

from math import cos

print('The cosinus of 0 is :', cos(0))

from my_module import *

print('The variable is :', my_variable)

addition(50)
