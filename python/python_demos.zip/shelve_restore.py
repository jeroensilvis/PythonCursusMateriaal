import shelve

db = shelve.open('shelve_dump')
data = db['list']
db.close()
print(data)

