from datetime import datetime

now = datetime.now()
print(now)
a_date = datetime(2018,12,20,8,15,20,123474)
print(a_date)
string_date = a_date.strftime('%Y-%m-%d')
print(string_date)