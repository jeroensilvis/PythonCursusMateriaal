import random

l = [random.randint(0,100000)for i in range(100)]
#print(l)
print([i for i in l if i%2==0])
result = list(filter(lambda x:x%2==0,l))
print(result)



