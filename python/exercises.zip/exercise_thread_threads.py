import requests
from datetime import datetime
import threading


def download_file():
    with requests.get('http://effbot.org/media/downloads/librarybook-threads-and-processes.pdf') as result:
        if result.status_code == 200:
            with open('example.pdf', 'wb') as f:
                f.write(result.content)


start_time = datetime.now()
thread_list = []
for _ in range(10):
    t = threading.Thread(target=download_file)
    t.start()
    thread_list.append(t)
for t in thread_list:
    t.join()
end_time = datetime.now()
print('Threads:duration of execution: ', end_time - start_time)