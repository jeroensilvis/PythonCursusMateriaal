import sqlite3
from person1 import Employee

admin = list()
with open('employees2.txt') as f:
    for line in f:
        e_list = line.split()
        admin.append(Employee(e_list[0],e_list[1],int(e_list[2])))

