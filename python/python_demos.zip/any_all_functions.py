l = [1, 4, 0, 6, 2]
print(all(l))
print(any(l))
t = (None, 'Hello', 1)
print(all(t))
print(any(t))
