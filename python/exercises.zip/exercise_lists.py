print(len(set([1,5,4,8,2,1,4,8,5])))

s = [n for n in ['hello','how','are','you'] if len(n) > 3]
print(s)

l1 = [10,20,30,40]
l2 = [30,40]
l3 = list(set(l1)-set(l2))
print(l3)

d1 = {1:2}
d2 = {3:4}
d3.copy(d1)
#d3 = dict()
#d3.update(d1)
d3.update(d2)
print(d3)
