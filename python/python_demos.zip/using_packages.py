import graphics.primitive.lines

graphics.primitive.lines.lines_print()

