class Static:
    stat_var = 10

    @staticmethod
    def statmethod(data):
        Static.stat_var += data


Static.statmethod(100)
print(Static.stat_var)