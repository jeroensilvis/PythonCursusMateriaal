s = (1, 2, 3,)
t = (4, 5, 6,)
print(s + t)
print(s * 4)
