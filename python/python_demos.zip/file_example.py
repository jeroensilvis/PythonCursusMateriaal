f = open('data.txt','w')
f.write('Hello')
f.write(' world\n')
f.close()
f = open('data.txt')
text = f.read()
print(text)
f.close()

f = open('data.txt','w')
count = f.write('Hello\n')
print(count)
f.write('World\n')
f.write('Next line\n')
f.close()

f = open('data.txt')
for line in f:
    print(line)

f.seek(0)
for line in f:
    print(line,end='')
f.close()

