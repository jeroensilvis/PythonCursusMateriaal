from collections import Counter

c = Counter('we make a character count of this sentence')
print(c)

print(list(c.elements()))
print(c.most_common(3))


c = Counter(a=4, b=2, c=0, d=-2)
d = Counter(a=1, b=2, c=3, d=4)
c.subtract(d)
print(c)