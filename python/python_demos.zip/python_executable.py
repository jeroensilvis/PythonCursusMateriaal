#!/usr/bin/python
import sys

print('The number of arguments is :', len(sys.argv))
print('Argument lis:', str(sys.argv))
