class Building:
    '''
    *
    This is a very important class building
    '''

    def __init__(self,name,city,street,number, yearBuild, wozValue):
        '''

        The init uses params: name, city, street,number, yearBuild, wozValue
        '''
        self._name = name
        self._city = city
        self._street = street
        self._number = number
        self._yearBuild = yearBuild
        self._wozValue = wozValue

    def increaseWoz(self,amount):
        '''

        increaseWoz only increases upto 100000
        '''
        if self._wozValue + amount > 100000:
            self._wozValue = 100000
        else:
            self._wozValue += amount

    def __str__(self):
        return self._name + ' ' +self._city +' '+ str(self._wozValue)

class Hotel(Building):

    def __init__(self,name,city,street,number, yearBuild, wozValue, nrOfRooms, roomPrice):
        super().__init__(name,city,street,number, yearBuild, wozValue)
        self._nrOfRooms = nrOfRooms
        self.roomPrice = roomPrice

h = hotel('Hilton','Amsterdam','Apollolaan',137,1960,20000,100,570)


        

    
