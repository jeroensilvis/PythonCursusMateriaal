name = input('Give me your name :')
age = int(input('Give me your age :'))
print(name)
print(age)
