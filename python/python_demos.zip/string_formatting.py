print('The sun is %s' % 'shining')
print('Her name is %s and her age is %d' % ('Mary', 35))
print('%f %.2f' % (1 / 3, 1 / 3))

print('Her name is {0} and her age is {1}'.format('Mary', 35))
print('Her age is {1} and her name is {0}'.format('Mary', 35))
print('Her name is {} and her age is {}'.format('Mary', 35))

print('{0:f},{1:8.2f}'.format(1 / 3, 1 / 7))

name = 'Fred'
age = 50
s1 = f'My name is {name}, my age next year is {age+1}'
print(s1)

s1 = 'A string which continues \
     on the next line'
s2 = 'A string with a\n linefeed'
s3 = '''A string
        spanning
        more lines'''
s4 = 'A string with a back slash \\'
print(s1)
print(s2)
print(s3)
print(s4)

l = 'H,e,l,l,o'.split(',')
print(l)

