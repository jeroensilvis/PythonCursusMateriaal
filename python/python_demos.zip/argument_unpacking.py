def print_elements(x, y, z):
    print(x, y, z)


print_elements(40, 50, 60)

t = (100, 200, 300)

print_elements(t)

print_elements(*t)

s = ['a', 'b', 'c']

print_elements(*s)

e = (x ** 2 for x in range(3))

print(e)

print_elements(*e)

d = {'x': 100, 'y': 200, 'z': 300}
print_elements(**d)
