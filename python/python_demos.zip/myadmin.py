from person import Employee

employees = [Employee('Dave', 37, 4000),Employee("Amy", 31, 5000),Employee("Andy",45,4500)]

employees.sort()
for e in employees:
    print(e)