import aiohttp
import asyncio
from datetime import datetime


async def download_file():
    async with aiohttp.ClientSession() as session:
        async with session.get('http://effbot.org/media/downloads/librarybook-threads-and-processes.pdf') as result:
            if result.status == 200:
                with open('example.pdf', 'wb') as f:
                    f.write(await result.read())


async def do_it():
    coroutines = [download_file() for i in range(10)]
    await asyncio.wait(coroutines)


loop = asyncio.get_event_loop()
start_time = datetime.now()
try:
    loop.run_until_complete(do_it())
finally:
    end_time = datetime.now()
    print('asyncio:duration of execution: ', end_time - start_time)
    loop.close()
