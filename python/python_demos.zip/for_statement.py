for i in range(10):
    print(i, end=',')
else:
    print('Out of range')
