class Person:
    """
    This is a person
    """

    def __init__(self, firstname='Unknown', lastname='Unknown', age=-1):
        self.__firstname = firstname
        self.__lastname = lastname
        self.__age = age

    def setfirstname(self, firstname):
        self.__firstname = firstname

    def getfirstname(self):
        return self.__firstname

    def setlastname(self, lastname):
        self.__lastname = lastname

    def getlastname(self):
        return self.__lastname

    def setage(self, age):
        self.__age = age

    def getage(self):
        return self.__age

    def __str__(self):
        return self.__firstname + " " + self.__lastname + " " + str(self.__age)

    def __lt__(self, other):
        return self.getlastname() < other.getlastname()

    def __eq__(self,other):
        if self.getfirstname()==other.getfirstname() and self.getlastname() ==other.getlastname() and self.getage() == other.getage():
            return True
        else:
            return False

    def __call__(self):
        return self.getfirstname()



persons = list()
persons.append(Person('John', 'Black', 30))
persons.append(Person('Mary', 'White', 27))
persons.append(Person('Leo', 'Yellow', 56))
persons.append(Person('Ingrid', 'Brown', 43))
# persons.sort()
persons1 = reversed(persons.sort())

for p in persons:
    print(p)

p1 = Person('Bart', 'Law', 22)
p2 = Person('Bart', 'Law', 22)

if p1 == p2:
    print('equal')
else:
    print('not equal')

print(p1())