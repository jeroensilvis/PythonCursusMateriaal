#!/usr/bin/env python3
import math

print('Please input numbers. The program will check if it is prime')
print('Use Ctrl+c to stop')
while True:
    try:
        number = int(input('Input a number\n'))
    except:
        exit()
    for i in range(2, math.floor(number / 2 + 1)):
        if number % i == 0:
            prime = False
            print('%d is not prime' % number)
            break
    else:
        print('%d is prime' % number)
