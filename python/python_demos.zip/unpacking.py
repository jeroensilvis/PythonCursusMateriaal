t = (2, 3)
a, b = t
print('a is :', a)
print('b is :', b)

data = ['Hello', 3, 80.41, (1, 2, 3)]
word, index, amount, element = data
print(word, index, amount, element)

_, index, amount, _ = data
print(index, amount)

record = ('Hans', 'Drupsteen', '0101234567', '061234567')
firstName, lastName, *phoneNumbers = record
print(firstName, lastName, phoneNumbers)

some_data = ['first_element', 1, 2, 34, 5, 11, 'last_element']
first, *_, last = some_data
print(first, last)
