import requests
from datetime import datetime
import multiprocessing as m


def download_file():
    with requests.get('http://effbot.org/media/downloads/librarybook-threads-and-processes.pdf') as result:
        if result.status_code == 200:
            with open('example.pdf', 'wb') as f:
                f.write(result.content)


start_time = datetime.now()
process_list = []
for _ in range(10):
    p = m.Process(target=download_file)
    p.start()
    process_list.append(p)
for p in process_list:
    p.join()
end_time = datetime.now()
print('Processes:duration of execution: ', end_time - start_time)