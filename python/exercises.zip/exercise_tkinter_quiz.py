from tkinter import *
from tkinter import messagebox
import requests
import json


class QuizItem:

    def __init__(self, question, answer, cat, diff):
        self.question = question
        self.answer = answer
        self.cat = cat
        self.diff = diff


class QD:
    """
    This class contains the quiz and relevant quiz data
    """
    quiz = None
    item_index = 0
    score = 0
    index = 0


def get_quiz():
    quiz = []
    r = requests.get('https://excelbianserver.com/quiz/quiz.json', verify=False)
    if r.status_code == 200:
        r = json.loads(r.text)
        items = r['quiz']
        for item in items:
            quiz.append(QuizItem(item['question'], item['answer'], item['category'], item['difficulty']))
    return quiz


def make_quiz(quiz, difficulty):
    return [item for item in quiz if item.diff == difficulty]


def question():
    return QD.quiz[QD.index].question


def answer():
    return QD.quiz[QD.index].answer


def check_answer():
    if entry.get().lower() == QD.quiz[QD.index].answer.lower():
        messagebox.showinfo("Answer", "Correct!")
        QD.score += 1
    else:
        messagebox.showinfo('Answer', 'Not Correct')
    if QD.index == len(QD.quiz)-1:
        messagebox.showinfo("Your result", "You have {} answers out of {} correct".format(QD.score,len(QD.quiz)))
        QD.index = 0
    else:
        QD.index += 1
        score_label.config(text="Your score is {} out of {} questions".format(QD.score,len(QD.quiz)))
    question_label.config(text=QD.quiz[QD.index].question)


QD.quiz = get_quiz()
window = Tk()
window.title('Quiz')
window.config(background='blue')
window.geometry('900x600')
question_label = Label(window)
question_label.config(height=3, bg='yellow', text=question())
entry = Entry(window)
# entry.config()
score_label = Label(window)
score_label.config(width=50, bg='blue', fg='white',text="Your score is {} out of {} questions".format(QD.score,len(QD.quiz)))
ok_button = Button(text="OK", command=check_answer)
# ok_button.config(bg='yellow')
question_label.pack(fill=X, pady=20, padx=20)
entry.pack(fill=X, pady=20, padx=20)
ok_button.pack(pady=20)
score_label.pack(pady=20, padx=40)
window.mainloop()
