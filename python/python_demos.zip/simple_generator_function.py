def simple_generator_function():
    yield print('a')
    yield print('b')
    yield print('c')


generate = simple_generator_function()
next(generate)
next(generate)
next(generate)
