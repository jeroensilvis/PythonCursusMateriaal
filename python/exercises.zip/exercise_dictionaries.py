result = dict()
a = {'a':10,'b':20}
b = {'c':100,'d':200}
c = {'a':50,'e':300}
result.update(a)
result.update(b)
result.update(c)
print(result)