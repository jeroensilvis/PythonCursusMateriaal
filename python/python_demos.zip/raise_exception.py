def raise_exception():
    raise Exception('My exception')


raise_exception()
