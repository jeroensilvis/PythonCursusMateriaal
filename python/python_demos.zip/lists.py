s = ['Hello', 10, 3.3]
print(s)
s = [10]
print(s)
s = []
print(s)
s = list('Hello')
print(s)
s = list()
print(s)

print([1, 2] + [3, 4])
s = [3, 'Hello', 5.4]
print(s[0])
print(s[1])
s[2] = 15.9
print(s)
print([1, 2] * 3)
