import sqlite3

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("DELETE FROM Employee WHERE Id=1")
    print('Total number of rows updated :', conn.total_changes)
    result = cursor.execute("SELECT * FROM Employee")
    result = cursor.fetchall()
    print(result)
