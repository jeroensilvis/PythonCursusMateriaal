import sqlite3

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM Employee WHERE Salary > 4000")
    while True:
        row = cursor.fetchone()
        if row is None:
            break
        print(row[1], row[2])
