class Myclass:

    def myfunc(self):
        print('This is a method')


c = Myclass()
c.myfunc()
