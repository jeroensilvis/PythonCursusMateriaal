def function_uses_global():
    global s
    print(s)


s = 'This is a global variable'
function_uses_global()
