d = {'e': 12, 'f': 4, 'x': 400}
print(d)
d = {6: 2, 9: 11}
print(d)
d = dict()
print(d)
d = dict(g=3, w=12.5, z='hello')
print(d)
d = dict([(2, 3), (8, 4)])
print(d)
d = dict(((3, 8), (9, 15)))
print(d)

d = {'a': 1, 'b': 2, 'c': 3}
print(d['a'])
d['c'] = 20
print(d)
d['k'] = 100
print(d)

d = {'a': 4, 'g': 8}
print(d)
print(d.keys())
print(d.values())
print(d.items())
d.pop('a')
print(d)
d2 = {3: 9, 5: 1, 'g': 500}
d.update(d2)
print(d)
print(d.get('g'))
