import requests
from datetime import datetime


def download_file():
    with requests.get('http://effbot.org/media/downloads/librarybook-threads-and-processes.pdf')as result:
        if result.status_code == 200:
            with open('example.pdf', 'wb') as f:
                f.write(result.content)


start_time = datetime.now()
for _ in range(10):
    download_file()
end_time = datetime.now()
print('Sequential:duration of execution: ', end_time - start_time)