import shelve

data = ['Hello', 1, {'a': 1, 'b': 2}, 'd']
db = shelve.open('shelve_dump')
db['list'] = data
db.close()
