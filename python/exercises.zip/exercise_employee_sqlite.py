from employee import Employee
import sqlite3

e1 = Employee('Lily', 3000)
e2 = Employee('Joyce', 2995)
e3 = Employee('Mark', 2990)

print(e1)
print(e2)
print(e3)


def query(id, e):
    return 'INSERT INTO Employee VALUES(' + str(id) + ',\'' + e.name + '\',' + str(e.salary) + ')'


conn = sqlite3.connect('employee.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("Drop TABLE Employee")
    cursor.execute("Create TABLE Employee(id INT, Name TEXT, Salary INT)")
    cursor.execute(query(1, e1))
    cursor.execute(query(2, e2))
    cursor.execute(query(3, e3))

    employee_list = []
    cursor.execute('SELECT * from Employee')
    while True:
        row = cursor.fetchone()
        if row is None:
            break
        employee_list.append(Employee(row[1], row[2]))

    for e in employee_list:
        print(e)
