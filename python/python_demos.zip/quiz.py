import requests
import sqlite3
from quizitem import QuizItem


def get_quiz(url):
    data = requests.get(url)
    if data.status_code == 200:
        result = data.json()
        return result['quiz']
    else:
        return dict()


def create_item_list(items):
    return [QuizItem(e['id'], e['question'], e['answer'], e['category'], e['difficulty']) for e in items]


def do_quiz(items):
    print('We start the quiz')
    for item in items:
        answer = input(item.question + '\n')
        if answer == item.answer:
            print('The answer is correct')
        else:
            print("The answer is not correct")


def store_item_dicts(items):
    item_list = [tuple(item.values()) for item in items]
    with sqlite3.connect("quiz.db") as con:
        cursor = con.cursor()
        cursor.execute("Drop table if exists Quiz")
        cursor.execute("Create table if not exists Quiz(id INT,question TEXT,answer TEXT,cat TEXT, diff TEXT)")
        cursor.executemany("Insert into Quiz Values(?,?,?,?,?)",item_list)

def store_item_objects(object_list):
    item_list = [o.make_tuple() for o in object_list]
    with sqlite3.connect("quiz.db") as con:
        cursor = con.cursor()
        try:
            cursor.execute("Drop table Quiz")
        except sqlite3.OperationalError:
            print("Table doesnt exist")
        cursor.execute("Create table if not exists Quiz(id INT,question TEXT,answer TEXT,cat TEXT, diff TEXT)")
        cursor.executemany("Insert into Quiz Values(?,?,?,?,?)", item_list)


if __name__ == '__main__':
    result = get_quiz("http://excelbianserver.com/quiz/quiz.json")
    # store_item_dicts(result)
    quiz_items = create_item_list(result)
    store_item_objects(quiz_items)
    do_quiz(quiz_items)
