from playground import Account, SavingsAccount


a = Account('Andre',500)
print(a)
s = SavingsAccount('Rene',1000,10)
print(s)