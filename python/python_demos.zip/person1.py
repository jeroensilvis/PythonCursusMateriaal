class Person:

    def __init__(self,name=''):
        self._name = name

    def get_name(self):
        return self._name

    def set_name(self,name):
        self._name = name

    def __str__(self):
        return self.get_name()


class Employee(Person):
    _emp_nr = 0

    def __init__(self,name,role,salary):
        super().__init__(name)
        Employee._emp_nr += 1
        self._nr = Employee._emp_nr
        self._role = role
        self._salary = salary

    @classmethod
    def get_nr_of_employees(cls):
        return cls._emp_nr

    def get_nr(self):
        return self._nr

    def get_role(self):
        return self._role

    def set_role(self,role):
        self._role = role

    def get_salary(self):
        return self._salary

    def set_salary(self,salary):
        self._salary = salary

    def raise_salary(self,percentage):
        self._salary *= (percentage/100 +1)


    def __str__(self):
        return super().__str__() + ' ' + str(self.get_nr()) + ' ' + self.get_role() + ' ' + str(self.get_salary())
