import math

print(dir(math))
