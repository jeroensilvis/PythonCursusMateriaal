def get_input():
    try:
        x = int(input('Enter a number\n'))
    except ValueError:
        print('Not a number')
    else:
        print('Input was a number')


get_input()
