items = [1, 2, 3, 4]


def sqr(x):
    return x ** 2


print(list(map(sqr, items)))

print(list(map(lambda x: x ** 2, items)))

print([n ** 2 for n in items])
