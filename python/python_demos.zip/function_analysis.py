def my_func(first, second=0, *third, **fourth):
    local_var = 10
    return local_var


print(my_func.__code__
      , my_func.__code__.co_code
      , my_func.__code__.co_argcount
      , my_func.__defaults__
      , my_func.__kwdefaults__
      , my_func.__dict__
      , my_func.__code__.co_varnames
      , my_func.__code__.co_name
      , my_func.__code__.co_nlocals
      , sep='\n')


print(dir(my_func))