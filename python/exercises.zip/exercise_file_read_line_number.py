f1 = open('file1.txt','w')
f1.write('line 1\n')
f1.write('line 2\n')
f1.write('line 3\n')
f1.close()

f1 = open('file1.txt','r')
f2 = open('file2.txt','w')
index =0
for line in f1:
    index = index +1
    f2.write(str(index) + ' ' + line)
f1.close()
f2.close()
