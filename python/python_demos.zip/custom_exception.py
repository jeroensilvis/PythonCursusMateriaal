class MyException(Exception):

    def __init__(self, errno, message):
        self.args = (errno, message)
        self.errno = errno
        self.errmsg = message


raise MyException(1, 'Severe problem')
