# Create a function which makes  a connection with http://excelbianserver.com/python_training/exception.php
# The server returns an integer between 1 and 2000 (1, 2000 included).
# When the returned integer is between 1 and 1000 (included) the integer is returned by the function
# When the returned integer is higher than 1000 the function raises a custom exception MyCustomException.
# The custom exception must have the following attributes: errno, message,return_value
# Create the MyCustomException, create the function, use the function in a program that excepts the exception


import requests


class MyCustomException(Exception):

    def __init__(self, errno, message, return_value):
        self.errno = errno
        self.message = message
        self.return_value = return_value


def fetch_number():
    result = requests.get('https://excelbianserver.com/python_training/exception.php')
    if result.status_code == 200:
        nr = int(result.text)
        if nr <= 1000:
            return nr
        else:
            raise MyCustomException(1, 'Received wrong value', nr)
    else:
        raise MyCustomException(2, 'Not a result received', result.status_code)


if __name__ == '__main__':
    try:
        print(f'Number received {fetch_number()}')
    except MyCustomException as e:
        print(f'MyCustomException: {e.message} with value {e.return_value}')

# import requests
#
#
# class MyCustomException(Exception):
#
#
#     def __init__(self, errno, message, return_value):
#         self.errno = errno
#         self.message = message
#         self.return_value = return_value
#
#
# def my_func():
#     result = requests.get('http://excelbianserver.com/python_training/exception.php')
#     answer = int(result.text)
#     if answer > 1000:
#         raise MyCustomException(1,'wrong value exception',answer)
#     else:
#         return answer
#
#
# try:
#     print(my_func())
# except MyCustomException as e:
#         print(f'{e.message} with return_value {e.return_value}')
