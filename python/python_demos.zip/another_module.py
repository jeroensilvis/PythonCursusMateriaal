import my_module

print('The variable is :', my_module.my_variable)

my_module.addition(50)
