class Person:
    def __init__(self, firstname='', lastname='', age=-1):
        self.firstname = firstname
        self.lastname = lastname
        self.age = age

    def __str__(self):
        return self.firstname + ' ' + self.lastname + ' ' + str(self.age)

    def getfullname(self):
        return self.firstname + ' ' + self.lastname


p1 = Person('John', 'Michels', 34)

print(p1.getfullname())
