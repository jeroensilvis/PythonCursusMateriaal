import requests

r = requests.get('https://api.github.com/events')
if r.status_code == 200:
    print(r.text)

r = requests.get('https://api.github.com/user', auth=('your_user_name', 'your_password'))
if r.status_code == 200:
    print(r.text)
else:
    print("request failed")

r = requests.post('http://httpbin.org/post', data={'key': 'value'})

r = requests.get('https://api.github.com/events')
if r.status_code == requests.codes.ok:
    print(r.text)

try:
    requests.get('http://github.com', timeout=0.001)
except requests.exceptions.Timeout as e:
    print(e)
