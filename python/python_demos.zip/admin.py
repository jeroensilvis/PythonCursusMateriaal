from person import Employee
import sqlite3

employees = list()
with open('employees.txt') as f:
    for line in f:
        line = line.rstrip()
        l = line.split(',')
        employees.append(Employee(l[0], l[1], l[2], l[3]))
print(employees)

e_list = list()
for index, e in enumerate(employees):
    e_list.append((index + 1, e.get_first_name(), e.get_last_name(), e.get_age(), e.get_salary()))
print(e_list)

conn = sqlite3.connect('employees1.db')
with conn:
    cursor = conn.cursor()
    cursor.execute("DROP TABLE employees")
    cursor.execute("CREATE TABLE employees(id INT, first_name TEXT, "
                   "last_name TEXT, age INT, salary INT)")
    cursor.executemany("INSERT INTO employees VALUES(?,?,?,?,?)", e_list)
