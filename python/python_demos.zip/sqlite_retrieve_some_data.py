import sqlite3

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("SELECT FirstName FROM Employee")
    print(list(cursor))
