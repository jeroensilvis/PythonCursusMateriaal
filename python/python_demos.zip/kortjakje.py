import matplotlib
matplotlib.use("TkAgg")
import matplotlib.pyplot as plt

with open('kortjakje.txt') as f:
    text = f.read()
    words = text.split()
word_count = dict()
for word in words:
    if word in word_count:
        word_count[word] += 1
    else:
        word_count[word] = 1
print(word_count)
count_list = list(word_count.items())
count_list.sort(key=lambda p: p[1], reverse=True)
print(count_list)

x = [x[0] for x in count_list]
y = [x[1] for x in count_list]
plt.plot(x,y)
plt.xticks(x,x, rotation='vertical')
plt.show()

