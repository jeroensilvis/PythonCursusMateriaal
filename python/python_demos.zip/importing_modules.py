import math
import random

print('Pi is :',math.pi)
print('A random number :',random.random())


