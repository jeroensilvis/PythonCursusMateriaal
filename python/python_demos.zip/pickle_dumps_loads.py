import pickle

data = ['Hello', 1, {'a': 1, 'b': 2}, 'd']
the_output = pickle.dumps(data)
print(the_output)
result = pickle.loads(the_output)
print(result)
