global_var = 'global var'

if True:
    block_var = 'block var'


def my_func():
    local_var = 'function var'


print(global_var)
print(block_var)
print(local_var)
