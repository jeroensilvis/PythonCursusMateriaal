def print_something():
    print('Something is printed')


def get_squares(max_value):
    return [n ** 2 for n in range(max_value)]


print_something()
print(get_squares(10))
