class Account:
    def __init__(self, name, balance):
        self.name = name
        self.balance = balance

    def get_balance(self):
        return self.balance


a = Account('Hans', 1000)
print(a.__dict__)

a.age = 30
print(a.__dict__)

a.__dict__['gender'] = 'male'
print(a.__dict__)

del a.age
print(a.__dict__)

del a.__dict__['gender']
print(a.__dict__)

print(a.__class__.__dict__)

