counter = 0
while counter < 10:
    print(counter, end=',')
    counter += 1
else:
    print('Counter too large')

