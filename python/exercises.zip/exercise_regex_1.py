import re

my_string = 'dit is een string met alleen lower case characters en cijfers 1 2 3 4'
pattern = r'^[a-z0-9\s]*$'
match = re.search(pattern,my_string)
if match:
    print('true')
else:
    print('false')