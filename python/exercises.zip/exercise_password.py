
attempts = 0;
while attempts < 3:
    p = input('Give me your password :')
    if len(p) < 8:
        print ('Password too short')
        attempts +=1
    elif p.islower():
        print("Password doesn't have an upper case character")
        attempts +=1
    elif p.isalpha():
        print("Password doesn't have a digit")
        attempts +=1
print("login not successful")
