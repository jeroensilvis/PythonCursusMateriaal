import queue

q = queue.PriorityQueue()
q.put(10)
q.put(1)
q.put(5)
while not q.empty():
    print(q.get())

q = queue.PriorityQueue()
q.put(('ten', 10))
q.put(('one', 1))
q.put(('five', 5))
while not q.empty():
    print(q.get())
