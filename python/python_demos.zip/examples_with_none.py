a = None
print(a)
a = [None]
print(a)
a = a * 4
print(a)
