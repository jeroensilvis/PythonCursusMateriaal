s = 'Hello world!'
s[0] = 'h'

l = list(s)
l[0] = 'h'
print(''.join(l))
