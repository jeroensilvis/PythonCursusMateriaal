import os

print(os.name)
# uname() doesn't give info on non linux systems
print(os.uname())
print(os.environ)
print(os.getcwd())
print(os.getpid())
print(os.getlogin())

# os.rename('myvalues.txt','values.txt')
# os.rename('values.txt','myvalues.txt')
