from datetime import datetime, date, time

print(date.today())
print(datetime.now())

d = date(2017, 3, 1)
t = time(12, 30, 24)
dt = datetime.combine(d, t)
print(dt)
dt2 = datetime(2016, 12, 24, 16, 15)
print(dt2)
