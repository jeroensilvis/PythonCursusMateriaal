class Person:
    id = 0

    def __init__(self, name, age):
        self.name = name
        self.age = age

    @classmethod
    def get_id(cls):
        return cls.id


p = Person('Andrew', 30)

print(dir(p))
print(p.__dict__)

print(dir(type(p)))
print(type(p).__dict__)
