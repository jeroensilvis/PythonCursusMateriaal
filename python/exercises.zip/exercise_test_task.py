from collections import namedtuple

Task = namedtuple('Task',['content','owner','done'])

t = Task('something to do','me',False)

print(t)

t.content = 'nothing to do'