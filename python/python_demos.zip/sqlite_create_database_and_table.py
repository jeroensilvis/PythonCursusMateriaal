import sqlite3

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("Create TABLE Employee(Id INTEGER, FirstName TEXT,LastName TEXT, Salary INT)")
    cursor.execute("INSERT INTO Employee VALUES(1,'Hans','Zwart',2000)")
    cursor.execute("INSERT INTO Employee VALUES(2,'Mary','De Goede',2200)")
    cursor.execute("INSERT INTO Employee VALUES(3,'Joke','Bartels',2800)")
    cursor.execute("INSERT INTO Employee VALUES(4,'John','de Wit',3000)")
    cursor.execute("SELECT * FROM Employee")
    print(list(cursor))
