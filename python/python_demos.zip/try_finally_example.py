def do_some_stuff():
    pass


def cleanup_stuff():
    pass


try:
    do_some_stuff()
except:
    print('An exception')
finally:
    cleanup_stuff()
