x = 1
if x:
    y = 2
else:
    y = 3
print(y)
