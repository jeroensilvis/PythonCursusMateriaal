class Employee:
    nr_of_employees = 0

    def __init__(self, name, role, salary):
        self.name = name
        self.role = role
        self.salary = salary
        Employee.nr_of_employees +=1
        self.nr = Employee.nr_of_employees


    def __str__(self):
        return f'{self.nr} {self.name} {self.role} {self.salary} '
