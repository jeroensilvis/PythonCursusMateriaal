import sqlite3

conn = sqlite3.connect('employees.db')

with conn:
    cursor = conn.cursor()
    cursor.execute("DROP TABLE Employee")
    cursor.execute("DROP TABLE IF EXISTS Employee")
