orders = [['34587', 'Learning Python', 'Mark Lutz', 4, 40.95],
          ['98762', 'Programming Python', 'Mark Lutz', 5, 56.80],
          ['77226', 'Head First Python', 'Paul Barry', 3, 32.95],
          ['88112', 'Introduction in Python3', 'Bernd Klein', 3, 24.99]
          ]
# ***********************first
l = list()
for order in orders:
    total = order[3] * order[4]
    if total < 100:
        total += 10
    l.append((order[0], total))
print(l)












# ***********************second
l3 = list(map(lambda x: (x[0], x[3] * x[4]) if x[3] * x[4] >= 100 else (x[0], x[3] * x[4] + 10), orders))
print(l3)






l4 = [(x[0], x[3] * x[4]) for x in orders if x[3] * x[4] >= 100] + \
     [(x[0], x[3] * x[4] + 10) for x in orders if x[3] * x[4] < 100]
print(l4)