def var_par_function(first, *second, **third):
    print(first)
    print(second)
    print(third)


var_par_function(10)
var_par_function(10, 100, 200)
var_par_function(10, 100, 200, var1=20, var2=30)

