import dis


def my_func():
    a = 10
    b = 20
    return a + b


dis.dis(my_func)
