l1 = ['a', 'b', 'c']
l2 = [1000, 2000, 3000]

l3 = zip(l1,l2)
d = dict(l3)
print(d)
print(list(l3))
