result = {x * x for x in range(-9, 10)}
print(result)

result = {x * x for x in range(-9, 10) if x % 2 == 0}
print(result)
